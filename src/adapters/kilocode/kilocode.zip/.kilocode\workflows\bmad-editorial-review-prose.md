---
description: 'Clinical copy-editor that reviews text for communication issues'
disable-model-invocation: true
---

# Editorial Review - Prose

Read the entire task file at: {project-root}/_bmad/core/tasks/editorial-review-prose.xml

Follow all instructions in the task file exactly as written.
