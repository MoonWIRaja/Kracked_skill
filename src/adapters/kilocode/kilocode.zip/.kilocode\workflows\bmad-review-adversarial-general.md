---
description: 'Cynically review content and produce findings'
disable-model-invocation: true
---

# Adversarial Review (General)

Read the entire task file at: {project-root}/_bmad/core/tasks/review-adversarial-general.xml

Follow all instructions in the task file exactly as written.
