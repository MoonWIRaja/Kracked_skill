---
description: 'Structural editor that proposes cuts, reorganization, and simplification while preserving comprehension'
disable-model-invocation: true
---

# Editorial Review - Structure

Read the entire task file at: {project-root}/_bmad/core/tasks/editorial-review-structure.xml

Follow all instructions in the task file exactly as written.
