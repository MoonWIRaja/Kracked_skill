---
description: 'Orchestrates group discussions between all installed BMAD agents, enabling natural multi-agent conversations'
disable-model-invocation: true
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/core/workflows/party-mode/workflow.md, READ its entire contents and follow its directions exactly!
