---
name: 'help'
description: 'Get unstuck by showing what workflow steps come next or answering questions about what to do'
---

# help

Read the entire task file at: {project-root}/_bmad/core/tasks/help.md

Follow all instructions in the task file exactly as written.
