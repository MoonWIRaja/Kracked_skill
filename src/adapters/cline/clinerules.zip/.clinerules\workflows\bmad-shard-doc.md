---
name: 'shard-doc'
description: 'Splits large markdown documents into smaller, organized files based on level 2 (default) sections'
---

# shard-doc

Read the entire task file at: {project-root}/_bmad/core/tasks/shard-doc.xml

Follow all instructions in the task file exactly as written.
