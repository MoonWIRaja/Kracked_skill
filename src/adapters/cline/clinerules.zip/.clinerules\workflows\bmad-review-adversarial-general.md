---
name: 'review-adversarial-general'
description: 'Cynically review content and produce findings'
---

# review-adversarial-general

Read the entire task file at: {project-root}/_bmad/core/tasks/review-adversarial-general.xml

Follow all instructions in the task file exactly as written.
