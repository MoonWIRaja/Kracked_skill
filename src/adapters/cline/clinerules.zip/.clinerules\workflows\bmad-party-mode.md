---
description: 'Orchestrates group discussions between all installed BMAD agents, enabling natural multi-agent conversations'
auto_execution_mode: "iterate"
---

# party-mode

Read the entire workflow file at {project-root}/_bmad/core/workflows/party-mode/workflow.md

Follow all instructions in the workflow file exactly as written.
