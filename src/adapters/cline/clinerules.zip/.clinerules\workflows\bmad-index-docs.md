---
name: 'index-docs'
description: 'Generates or updates an index.md of all documents in the specified directory'
---

# index-docs

Read the entire task file at: {project-root}/_bmad/core/tasks/index-docs.xml

Follow all instructions in the task file exactly as written.
