---
name: 'brainstorming'
description: 'Facilitate interactive brainstorming sessions using diverse creative techniques and ideation methods'
disable-model-invocation: true
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @{project-root}/_bmad/core/workflows/brainstorming/workflow.md, READ its entire contents and follow its directions exactly!
